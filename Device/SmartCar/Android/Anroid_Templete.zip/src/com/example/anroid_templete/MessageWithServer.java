package com.example.anroid_templete;

class MessageFromServer{
	public static String Message;
	public String getMessage(){
		return Message;
	}
	public void setMessage(String str){
		Message = str;
		//System.out.println(Message);
	}
}
class MessageToServer{
	public static String Message;
	public String getMessage(){
		return Message;
	}
	public void setMessage(String str){
		Message = str;
		//System.out.println(Message);
	}
}