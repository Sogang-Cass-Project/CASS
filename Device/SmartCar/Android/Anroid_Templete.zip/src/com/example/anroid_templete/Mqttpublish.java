package com.example.anroid_templete;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class Mqttpublish extends Thread{
	
	String data = null;
	String name;
	
	String topic        = "test/123";
    String content      = "";
    int qos             = 2;
    String broker       = "tcp://163.239.22.43:1883";
    String clientId     = "JavaMqttPublishClient";
    MemoryPersistence persistence = new MemoryPersistence();
    
    MessageToServer SendingMessage = new MessageToServer();
    int i=1;
    
    
    public void Mqttpublish(){
			
	};
	
	public void run(){
		int max=1;
		
		 try {
	            MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
	            MqttConnectOptions connOpts = new MqttConnectOptions();
	            connOpts.setCleanSession(true);
	            System.out.println("Connecting to broker: "+broker);
	            sampleClient.connect(connOpts);
	            System.out.println("Connected");
	            //==============================
	            while(true){
	            	
	            	content="";
	            	
	            	MqttMessage message = new MqttMessage(content.getBytes());
		            message.setQos(qos);
	            	sampleClient.publish(topic, message);
	            	//System.out.println("Publishing : "+ content);
	            	try {
	            		Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            	
	            	if(i==8){
	            		break;
	            	}
	            }
	            
	            //==============================
	            System.out.println("Message published");
	            sampleClient.disconnect();
	            System.out.println("Disconnected");
	            System.exit(0);
	        } catch(MqttException me) {
	            System.out.println("reason "+me.getReasonCode());
	            System.out.println("msg "+me.getMessage());
	            System.out.println("loc "+me.getLocalizedMessage());
	            System.out.println("cause "+me.getCause());
	            System.out.println("excep "+me);
	            me.printStackTrace();
	        }
			
	}

}
