package com.example.anroid_templete;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;

import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends Activity {


	private static final String TAG = "Main";
	
	//BlueTooth
	private Button btn_Connect;
	private static final int REQUEST_CONNECT_DEVICE = 1;
	private static final int REQUEST_ENABLE_BT = 2;
	private BluetoothService btService = null;
		
	//Wifi
	WifiManager wifi;
	private Button wifion;
	private Button wifiConnection;
	
	//Register
	private Button Register;
	private boolean registeron = true;
	
	//Mqtt
	private Button Mqtt;
	private boolean mqttton = true;
	
	private final Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		//Bluetooth
				btn_Connect = (Button) findViewById(R.id.bluetooth);
				
				if (btService == null) {
					btService = new BluetoothService(this, mHandler);
				}
				btn_Connect.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						if (btService.getDeviceState()) {
							btService.enableBluetooth();

						} else {
							finish();
						}
					}
				});

				
				
				//Wifi
				wifion = (Button) findViewById(R.id.Wifion);
				wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
				
				if (wifi.getWifiState() == WifiManager.WIFI_STATE_ENABLED) {
					wifion.setEnabled(false);
				}
				wifion.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						
					}
				});
				
				
				wifiConnection = (Button) findViewById(R.id.wifiConnect);
				wifiConnection.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						
						Log.d("WifiPreference", "add Network returned ");
						// TODO Auto-generated method stub
						String ssid = "AS712a";
						String password = "dcclab(!)";
						String cap = "WPA";
						connectWifi(ssid, password, cap);
										
					}
				});
				
				//REGISTER
				Register = (Button) findViewById(R.id.register);
				Register.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Log.d(TAG,"Start MQTT");
						
						Device_Regist reg = new Device_Regist();
						reg.start();
															
						if(registeron == true){
							registeron = false;
							Register.setActivated(registeron);
							Register.setEnabled(registeron);
						}
						
					}
				});
				//MQTT
				Mqtt = (Button) findViewById(R.id.mqtt);
				Mqtt.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Log.d(TAG,"Start MQTT");
						
						Mqttpublish  mqttpub = new Mqttpublish();
						mqttpub.start();
						
						Mqttsubscribe mqttsub = new Mqttsubscribe();
						mqttsub.start();
										
						if(mqttton == true){
							mqttton = false;
							Mqtt.setActivated(mqttton);
							Mqtt.setEnabled(mqttton);
						}
						
					}
				});
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	public boolean connectWifi(String ssid, String password, String capablities) {

		WifiConfiguration wfc = new WifiConfiguration();
		
		wfc.SSID = "\"".concat( ssid ).concat("\"");
		wfc.status = WifiConfiguration.Status.DISABLED;
		wfc.priority = 40;

		if(capablities.contains("WEP") == true ){
			wfc.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
			wfc.allowedProtocols.set(WifiConfiguration.Protocol.RSN);
			wfc.allowedProtocols.set(WifiConfiguration.Protocol.WPA);
			wfc.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);
			wfc.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.SHARED);
			wfc.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
			 
			wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
			wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP104);
			wfc.wepKeys[0] = "\"".concat(password).concat("\"");
			wfc.wepTxKeyIndex = 0;					
		}else if(capablities.contains("WPA") == true ) {
			wfc.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);
			wfc.allowedProtocols.set(WifiConfiguration.Protocol.RSN);
			wfc.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
			wfc.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
			wfc.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
			wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
			wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
			wfc.preSharedKey = "\"".concat(password).concat("\"");
		}else if(capablities.contains("WPA2") == true ) {
			wfc.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);
			wfc.allowedProtocols.set(WifiConfiguration.Protocol.RSN);
			wfc.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
			wfc.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
			wfc.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
			wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
			wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
			wfc.preSharedKey = "\"".concat(password).concat("\"");
		}else if(capablities.contains("OPEN") == true ) {
			wfc.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
			wfc.allowedProtocols.set(WifiConfiguration.Protocol.RSN);
			wfc.allowedProtocols.set(WifiConfiguration.Protocol.WPA);
			wfc.allowedAuthAlgorithms.clear();
			wfc.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
			 
			wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
			wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP104);
			wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
			wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
		}


		WifiManager wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
		int networkId = wifi.addNetwork(wfc);

		boolean connection = false;
		if (networkId != -1) {
			Toast.makeText(this, "���� �õ��մϴ�.\n mantdu.tistory.com", Toast.LENGTH_SHORT).show();
			connection = wifi.enableNetwork(networkId, true);
		}
		return connection;
		
	}
}
