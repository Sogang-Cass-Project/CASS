package com.example.anroid_templete;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.util.Log;

public class BluetoothService {

	private static final String TAG = "BluetoothService";
	private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
	
	private int mState;
	
	private static final int STATE_NONE = 0; // we're doing nothing
	private static final int STATE_LISTEN = 1; // now listening for incoming connections
	private static final int STATE_CONNECTING = 2; // now initiating an outgoing connection
	private static final int STATE_CONNECTED = 3; // now connected to a remote device
	
	
	// Intent request code
	private static final int REQUEST_CONNECT_DEVICE = 1;
	private static final int REQUEST_ENABLE_BT = 2;

	private BluetoothAdapter btAdapter;
	private ConnectThread mConnectThread;
	private ConnectedThread mConnectedThread;
	
	
	
	
	private Activity mActivity;

	private Handler mHandler;
	

	public BluetoothService(Activity ac, Handler h) {
		mActivity = ac;
		mHandler = h;

		btAdapter = BluetoothAdapter.getDefaultAdapter();
	}

	public BluetoothService(){
		btAdapter = BluetoothAdapter.getDefaultAdapter();
	}
	public boolean getDeviceState() {
		Log.i(TAG, "Check the Bluetooth support");

		if (btAdapter == null) {
			Log.d(TAG, "Bluetooth is not available");
			return false;
		} else {
			Log.d(TAG, "Bluetooth is available");
			return true;
		}

	}

	public void enableBluetooth() {
		Log.i(TAG, "Check the enabled BlueTooth");

		if (btAdapter.isEnabled()) {

			Log.d(TAG, "BlueTooth Enable Now");
			
			//scannDevice();
			String address = "20:15:08:20:07:43";
			
			BluetoothDevice device = btAdapter.getRemoteDevice(address);
	
			Log.d(TAG, "Get Device Info \n" + "address :" + address);
	
			connect(device);

		} 
		else {

			Log.d(TAG, "Bluetooth Enable Request");

		}

	}
	
	private class ConnectThread extends Thread{
		
		private final BluetoothSocket mmSocket;
		private final BluetoothDevice mmDevice;
		
		public ConnectThread(BluetoothDevice device){
			
			mmDevice = device;
			BluetoothSocket tmp = null;
			
			try{
				tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
				
			}
					
			catch(IOException e){
				Log.e(TAG, "Create() failed",e);
			}
			
			mmSocket = tmp;
			
		}
		
		public void run(){
			Log.i(TAG, "BEGIN mConnectThread");
			setName("ConnectThread");
			
			btAdapter.cancelDiscovery();
			try{
				mmSocket.connect();
				Log.d(TAG, "Connect Succeess");
			}
			catch(IOException e1 ){
				
				connectionFailed();
				Log.d(TAG, "Connect Fail");
				
				try {
					mmSocket.close();
					
				} catch (IOException e2) {
					// TODO: handle exception
					Log.e(TAG, "unable to close() socket during connection failure",e2);
				}
				BluetoothService.this.start();
				return;
			}
			
			synchronized (BluetoothService.this) {
				mConnectThread= null;
			}
			
			connected(mmSocket,mmDevice);
			
					
		}
		public void cancel() {
			try {
				mmSocket.close();
			} catch (IOException e) {
				Log.e(TAG, "close() of connect socket failed", e);
			}
		}
		
		
		
	}
	
	private class ConnectedThread extends Thread{
		private final BluetoothSocket mmSocket;
		private final InputStream mmInStream;
		private final OutputStream mmOutStream;
		MessageFromServer MessageToCar = null;;
		String data=null;
		
		
		public ConnectedThread(BluetoothSocket socket){
			Log.d(TAG, "create ConnectedThread");
			
			mmSocket = socket;
			InputStream tmpIn = null;
			OutputStream tmpOut = null;
			
			MessageToCar = new MessageFromServer();
			
			try {
				tmpIn = socket.getInputStream();
				tmpOut = socket.getOutputStream();
				
			} catch (IOException e) {
				// TODO: handle exception
				Log.e(TAG, "temp sockets not created",e);
			}
			
			mmInStream = tmpIn;
			mmOutStream = tmpOut;
		}
				
		public void run() {
			Log.i(TAG, "Begin mConnectedThread");
			byte[] buffer = new byte[1024];
			int bytes;
			
			try {
				while (true) {
					//read();
					
					
					data = MessageToCar.getMessage();
					if(data==null){
						
					}
					else{
						write(data);
						MessageToCar.setMessage(null);
						
					}
					//bytes = mmInStream.read(buffer);
				}
			} catch (Exception e) {
				// TODO: handle exception
				Log.e(TAG, "disconnected", e);
				connectionLost();
				
			}

		}
		public void read() {
			System.out.println("zz");
			byte[] buffer = new byte[1024];
			try {
				int z=mmInStream.read(buffer);
				System.out.println(new String(buffer));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public void write(String data) {
            String message = data;
            
            byte[] buffer = message.getBytes();
			try {
				Log.e(TAG, "Write data : "+data);
            	// ���� ���� �κ�(���� ������)
                mmOutStream.write(buffer);

            } catch (IOException e) {
                Log.e(TAG, "Exception during write", e);
            }
        }

        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "close() of connect socket failed", e);
            }
        }
	}
	private synchronized void setState(int state) {
		Log.d(TAG, "setState() " + mState + " -> " + state);
		mState = state;
	}

	// Bluetooth ���� get
	public synchronized int getState() {
		return mState;
	}

	public synchronized void start() {
		Log.d(TAG, "start");

		// Cancel any thread attempting to make a connection
		if (mConnectThread == null) {

		} else {
			mConnectThread.cancel();
			mConnectThread = null;
		}

		// Cancel any thread currently running a connection
		if (mConnectedThread == null) {

		} else {
			mConnectedThread.cancel();
			mConnectedThread = null;
		}
	}

	// ConnectThread �ʱ�ȭ device�� ��� ���� ����
	public synchronized void connect(BluetoothDevice device) {
		Log.d(TAG, "connect to: " + device);

		// Cancel any thread attempting to make a connection
		if (mState == STATE_CONNECTING) {
			if (mConnectThread == null) {

			} else {
				mConnectThread.cancel();
				mConnectThread = null;
			}
		}

		// Cancel any thread currently running a connection
		if (mConnectedThread == null) {

		} else {
			mConnectedThread.cancel();
			mConnectedThread = null;
		}

		// Start the thread to connect with the given device
		mConnectThread = new ConnectThread(device);

		mConnectThread.start();
		setState(STATE_CONNECTING);
	}

	// ConnectedThread �ʱ�ȭ
	public synchronized void connected(BluetoothSocket socket,BluetoothDevice device) {
		Log.d(TAG, "connected");

		// Cancel the thread that completed the connection
		if (mConnectThread == null) {

		} else {
			mConnectThread.cancel();
			mConnectThread = null;
		}

		// Cancel any thread currently running a connection
		if (mConnectedThread == null) {

		} else {
			mConnectedThread.cancel();
			mConnectedThread = null;
		}

		// Start the thread to manage the connection and perform transmissions
		mConnectedThread = new ConnectedThread(socket);
		mConnectedThread.start();

		setState(STATE_CONNECTED);
	}

	// ��� thread stop
	public synchronized void stop() {
		Log.d(TAG, "stop");

		if (mConnectThread != null) {
			mConnectThread.cancel();
			mConnectThread = null;
		}

		if (mConnectedThread != null) {
			mConnectedThread.cancel();
			mConnectedThread = null;
		}

		setState(STATE_NONE);
	}

	
	public void write(String out) { // Create temporary object
		ConnectedThread r; // Synchronize a copy of the ConnectedThread
		synchronized (this) {
			if (mState != STATE_CONNECTED)
				return;
			r = mConnectedThread;
			r.write(out);
		} // Perform the write unsynchronized r.write(out); }
	}

	
	private void connectionFailed() {
		setState(STATE_LISTEN);
	}

	
	private void connectionLost() {
		setState(STATE_LISTEN);

	}
	
	

}
